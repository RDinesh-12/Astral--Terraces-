import {MusicTrack} from './utils/helper';

/** Visual theme palette for Astral Terraces — Celestial Architectural Dreamworld. */
export const THEME = {
  fontDisplay: '"Cormorant Garamond", Georgia, serif',
  fontUi: '"Plus Jakarta Sans", system-ui, sans-serif',
  // Core Celestial Palette
  skyTop: '#e7d8e6',
  skyMid: '#c9c4e3',
  skyBottom: '#8ea8c9',
  fogColor: '#cfc5df',
  waterColor: '#5c729c',
  waterHighlight: '#9ec2d8',
  stoneCream: '#f3ece1',
  stoneShadow: '#dcd1c4',
  turquoise: '#7ebdb6',
  turquoiseDeep: '#56918c',
  sageGreen: '#95b89e',
  sageDeep: '#6c9178',
  lavenderArch: '#a498cc',
  lavenderDeep: '#766aa0',
  dustyRose: '#d998ab',
  mutedCoral: '#e0917a',
  beaconGold: '#f2d388',
  lanternAmber: '#f7c572',
  deepIndigo: '#272342',
  indigoShadow: '#3f3963',
  // UI Palette
  uiPanelBg: '#231f3b',
  uiPanelBorder: '#7d70a6',
  uiAccent: '#e0917a',
  uiAccentMint: '#7ebdb6',
};

/** Game configuration schema. */
export const CONFIG = {
  // --- Game ---
  title: {
    value: 'Astral Terraces',
    type: 'string',
    label: 'Game Title',
    group: 'GAME',
  },
  baseCanvasWidth: {
    value: 1280,
    type: 'number',
    label: 'Base Canvas Width',
    group: 'GAME',
  },
  baseCanvasHeight: {
    value: 720,
    type: 'number',
    label: 'Base Canvas Height',
    group: 'GAME',
  },

  // --- Camera ---
  fov: {
    value: 34,
    type: 'number',
    label: 'Field of View',
    group: 'Camera',
    min: 22,
    max: 60,
    step: 2,
  },
  cameraX: {
    value: 26,
    type: 'number',
    label: 'Camera X',
    group: 'Camera',
  },
  cameraY: {
    value: 26,
    type: 'number',
    label: 'Camera Y',
    group: 'Camera',
  },
  cameraZ: {
    value: 26,
    type: 'number',
    label: 'Camera Z',
    group: 'Camera',
  },
  cameraDistance: {
    value: 36,
    type: 'number',
    label: 'Camera Orbit Distance',
    group: 'Camera',
    min: 24,
    max: 48,
    step: 2,
  },

  // --- Visuals ---
  backgroundColor: {
    value: '#cfc5df',
    type: 'color',
    label: 'Background Color',
    group: 'Visuals',
  },
  primaryColor: {
    value: '#7ebdb6',
    type: 'color',
    label: 'Primary Color',
    group: 'THEME',
  },
  fontFamily: {
    value: '"Plus Jakarta Sans", system-ui, sans-serif',
    type: 'string',
    label: 'Font Family',
    group: 'THEME',
  },
  ambientColor: {
    value: '#f2e8f5',
    type: 'color',
    label: 'Ambient Light Color',
    group: 'Visuals',
  },
  ambientIntensity: {
    value: 1.55,
    type: 'number',
    label: 'Ambient Intensity',
    group: 'Visuals',
    min: 1.5,
    max: 4.0,
    step: 0.1,
  },
  sunColor: {
    value: '#fff5e4',
    type: 'color',
    label: 'Sun Color',
    group: 'Visuals',
  },
  sunIntensity: {
    value: 3.1,
    type: 'number',
    label: 'Sun Intensity',
    group: 'Visuals',
    min: 3.0,
    max: 8.0,
    step: 0.1,
  },
  hemiSkyColor: {
    value: '#eae0f7',
    type: 'color',
    label: 'Hemisphere Sky Color',
    group: 'Visuals',
  },
  hemiGroundColor: {
    value: '#5b537d',
    type: 'color',
    label: 'Hemisphere Ground Color',
    group: 'Visuals',
  },
  hemiIntensity: {
    value: 1.15,
    type: 'number',
    label: 'Hemisphere Intensity',
    group: 'Visuals',
    min: 0.5,
    max: 2.5,
    step: 0.1,
  },
  enableParticles: {
    value: true,
    type: 'boolean',
    label: 'Floating Mist Motes',
    group: 'Visuals',
  },

  // --- Gameplay & Rules ---
  moveSpeed: {
    value: 4.6,
    type: 'number',
    label: 'Traveler Speed',
    group: 'Rules',
    min: 2.5,
    max: 7.5,
    step: 0.5,
  },
  mechanismSpeed: {
    value: 3.6,
    type: 'number',
    label: 'Architecture Speed',
    group: 'Rules',
    min: 2.0,
    max: 6.0,
    step: 0.5,
  },
  pointsPerLevel: {
    value: 250,
    type: 'number',
    label: 'Points Per World',
    group: 'Rules',
    min: 100,
    max: 500,
    step: 50,
  },
  pointsPerRelic: {
    value: 150,
    type: 'number',
    label: 'Star Relic Bonus',
    group: 'Rules',
    min: 50,
    max: 300,
    step: 25,
  },

  // --- Physics ---
  gravity: {
    value: -9.81,
    type: 'number',
    label: 'Gravity',
    group: 'Physics',
    min: -30,
    max: 0,
    step: 0.5,
  },

  // --- System ---
  targetFPS: {
    value: 60,
    type: 'number',
    label: 'Target FPS',
    group: 'System',
  },
  stepMs: {
    value: 1000 / 60,
    type: 'number',
    label: 'Step MS',
    group: 'System',
  },
  maxSubSteps: {
    value: 5,
    type: 'number',
    label: 'Max Sub Steps',
    group: 'System',
  },

  // --- Audio ---
  defaultMusicVolume: {
    value: 0.18,
    type: 'number',
    label: 'Default Music Volume',
    group: 'AUDIO',
    min: 0,
    max: 0.5,
    step: 0.02,
  },
  defaultSfxVolume: {
    value: 0.6,
    type: 'number',
    label: 'Default SFX Volume',
    group: 'AUDIO',
    min: 0,
    max: 1,
    step: 0.1,
  },
  backgroundMusicUrl: {
    value:
      'https://storage.googleapis.com/assets-gen-playground/musiclibrary/zen_garden.mp3',
    type: 'string',
    label: 'Background Music URL',
    group: 'Audio',
  },
};

// Merge customized config values if present (injected by Playground)
const {playgroundConfig} = globalThis as {
  playgroundConfig?: Record<string, unknown>;
};
if (playgroundConfig) {
  for (const [key, value] of Object.entries(playgroundConfig)) {
    if (key in CONFIG) {
      Object.assign(CONFIG[key as keyof typeof CONFIG], {value});
    }
  }
}

/** Type helper for reading values in game code. */
export type ConfigKey = keyof typeof CONFIG;

/**
 * Gets a configuration value by key.
 * @param key The configuration key.
 * @return The configuration value.
 */
export function getConfig<K extends ConfigKey>(
  key: K,
): (typeof CONFIG)[K]['value'] {
  return CONFIG[key].value;
}

/** Optional presets for the game. */
export const PRESETS = {};

export const TOTAL_LEVELS = 10;

/** Background music tracks available for the game to use. */
export const AVAILABLE_MUSIC_TRACKS: readonly MusicTrack[] = [
  {
    name: 'zen_garden',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/zen_garden.mp3',
    description:
      'Tranquil koto, bamboo flute and bells. Use this for calm, meditative or zen puzzle games.',
  },
  {
    name: 'verdant_bloom',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/verdant_bloom.mp3',
    description:
      'A relaxing, nature-inspired track with a calm and peaceful atmosphere.',
  },
  {
    name: 'automated_dream',
    url: 'https://storage.googleapis.com/assets-gen-playground/musiclibrary/automated_dream.mp3',
    description:
      'An intellectually stimulating track with a calm architectural pulse.',
  },
];
